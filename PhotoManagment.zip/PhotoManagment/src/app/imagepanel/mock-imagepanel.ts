import { ImagePanel } from './ImagePanel';

export const IMAGEPANEL: ImagePanel[] = [
  // tslint:disable-next-line:max-line-length
  { link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },
  // tslint:disable-next-line:max-line-length
  { link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },
  // tslint:disable-next-line:max-line-length
  { link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },
  // tslint:disable-next-line:max-line-length
  { link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },
  // tslint:disable-next-line:max-line-length
  { link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },
// tslint:disable-next-line:max-line-length
{ link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },
// tslint:disable-next-line:max-line-length
{ link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },
// tslint:disable-next-line:max-line-length
{ link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },
// tslint:disable-next-line:max-line-length
{ link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },
// tslint:disable-next-line:max-line-length
{ link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },

// tslint:disable-next-line:max-line-length
{ link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },

// tslint:disable-next-line:max-line-length
{ link: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg', image: '/assets/img/00c76f87-0c6a-413d-8116-6d7f49d66838-MyRep-1F0C387C-2ECE-44EB-9908-8A4855FD16E4.jpg' },





];
