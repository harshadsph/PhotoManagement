export class ImagePanel {
  link: string;
  image: string;
}
