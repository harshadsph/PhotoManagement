export class NavbarServerData {
  }