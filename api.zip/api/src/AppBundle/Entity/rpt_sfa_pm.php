<?php

namespace AppBundle\Entity;

/**
 * rpt_sfa_pm
 */
class rpt_sfa_pm
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var String
     */
    private $taskid;

    /**
     * @var String
     */
    private $filename;

    /**
     * @var String
     */
    private $visitid;

    /**
     * @var String
     */
    private $customername;

    /**
     * @var String
     */
    private $storetype;

    /**
     * @var String
     */
    private $salesgroup;

    /**
     * @var String
     */
    private $distrChan;

    /**
     * @var String
     */
    private $mastertaskname;

    /**
     * @var String
     */
    private $salescampaignname;

    /**
     * @var String
     */
    private $salescyclename;

    /**
     * @var String
     */
    private $salesOffice;

    /**
     * @var String
     */
    private $mrchrVisitdate;

    /**
     * @var String
     */
    private $filepath;

    /**
     * @var String
     */
    private $brand;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set taskid
     *
     * @param String $taskid
     *
     * @return rpt_sfa_pm
     */
    public function setTaskid($taskid)
    {
        $this->taskid = $taskid;

        return $this;
    }

    /**
     * Get taskid
     *
     * @return String
     */
    public function getTaskid()
    {
        return $this->taskid;
    }

    /**
     * Set filename
     *
     * @param String $filename
     *
     * @return rpt_sfa_pm
     */
    public function setFilename($filename)
    {
        $this->filename = $filename;

        return $this;
    }

    /**
     * Get filename
     *
     * @return String
     */
    public function getFilename()
    {
        return $this->filename;
    }

    /**
     * Set visitid
     *
     * @param String $visitid
     *
     * @return rpt_sfa_pm
     */
    public function setVisitid($visitid)
    {
        $this->visitid = $visitid;

        return $this;
    }

    /**
     * Get visitid
     *
     * @return String
     */
    public function getVisitid()
    {
        return $this->visitid;
    }

    /**
     * Set customername
     *
     * @param String $customername
     *
     * @return rpt_sfa_pm
     */
    public function setCustomername($customername)
    {
        $this->customername = $customername;

        return $this;
    }

    /**
     * Get customername
     *
     * @return String
     */
    public function getCustomername()
    {
        return $this->customername;
    }

    /**
     * Set storetype
     *
     * @param String $storetype
     *
     * @return rpt_sfa_pm
     */
    public function setStoretype($storetype)
    {
        $this->storetype = $storetype;

        return $this;
    }

    /**
     * Get storetype
     *
     * @return String
     */
    public function getStoretype()
    {
        return $this->storetype;
    }

    /**
     * Set salesgroup
     *
     * @param String $salesgroup
     *
     * @return rpt_sfa_pm
     */
    public function setSalesgroup($salesgroup)
    {
        $this->salesgroup = $salesgroup;

        return $this;
    }

    /**
     * Get salesgroup
     *
     * @return String
     */
    public function getSalesgroup()
    {
        return $this->salesgroup;
    }

    /**
     * Set distrChan
     *
     * @param String $distrChan
     *
     * @return rpt_sfa_pm
     */
    public function setDistrChan($distrChan)
    {
        $this->distrChan = $distrChan;

        return $this;
    }

    /**
     * Get distrChan
     *
     * @return String
     */
    public function getDistrChan()
    {
        return $this->distrChan;
    }

    /**
     * Set mastertaskname
     *
     * @param String $mastertaskname
     *
     * @return rpt_sfa_pm
     */
    public function setMastertaskname($mastertaskname)
    {
        $this->mastertaskname = $mastertaskname;

        return $this;
    }

    /**
     * Get mastertaskname
     *
     * @return String
     */
    public function getMastertaskname()
    {
        return $this->mastertaskname;
    }

    /**
     * Set salescampaignname
     *
     * @param String $salescampaignname
     *
     * @return rpt_sfa_pm
     */
    public function setSalescampaignname($salescampaignname)
    {
        $this->salescampaignname = $salescampaignname;

        return $this;
    }

    /**
     * Get salescampaignname
     *
     * @return String
     */
    public function getSalescampaignname()
    {
        return $this->salescampaignname;
    }

    /**
     * Set salescyclename
     *
     * @param String $salescyclename
     *
     * @return rpt_sfa_pm
     */
    public function setSalescyclename($salescyclename)
    {
        $this->salescyclename = $salescyclename;

        return $this;
    }

    /**
     * Get salescyclename
     *
     * @return String
     */
    public function getSalescyclename()
    {
        return $this->salescyclename;
    }

    /**
     * Set salesOffice
     *
     * @param String $salesOffice
     *
     * @return rpt_sfa_pm
     */
    public function setSalesOffice($salesOffice)
    {
        $this->salesOffice = $salesOffice;

        return $this;
    }

    /**
     * Get salesOffice
     *
     * @return String
     */
    public function getSalesOffice()
    {
        return $this->salesOffice;
    }

    /**
     * Set mrchrVisitdate
     *
     * @param String $mrchrVisitdate
     *
     * @return rpt_sfa_pm
     */
    public function setMrchrVisitdate($mrchrVisitdate)
    {
        $this->mrchrVisitdate = $mrchrVisitdate;

        return $this;
    }

    /**
     * Get mrchrVisitdate
     *
     * @return String
     */
    public function getMrchrVisitdate()
    {
        return $this->mrchrVisitdate;
    }

    /**
     * Set filepath
     *
     * @param String $filepath
     *
     * @return rpt_sfa_pm
     */
    public function setFilepath($filepath)
    {
        $this->filepath = $filepath;

        return $this;
    }

    /**
     * Get filepath
     *
     * @return String
     */
    public function getFilepath()
    {
        return $this->filepath;
    }

    /**
     * Set brand
     *
     * @param String $brand
     *
     * @return rpt_sfa_pm
     */
    public function setBrand($brand)
    {
        $this->brand = $brand;

        return $this;
    }

    /**
     * Get brand
     *
     * @return String
     */
    public function getBrand()
    {
        return $this->brand;
    }
}

