<?php

namespace AppBundle\Controller;


use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\rpt_sfa_pm;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityManager;
use Doctrine\Common\Collections;


class ApiController extends Controller
{

    /**
     * @Route("/salescycle", name="getSalesCycle")
     */
    public function salesCycleAction()
    {
        $query_str = 'SELECT DISTINCT p.salescyclename FROM AppBundle\Entity\rpt_sfa_pm p';

       // $product = $this->getDoctrine()->getRepository(rpt_sfa_pm::class)->findAll();
        $em = $this->getDoctrine()->getManager();
        $query = $em->createQuery($query_str);  
        $query_result = $query->getResult(); 

        if (!$query_result) {
            throw $this->createNotFoundException(
                'No product found for id '.$productId
            );
            die();
        }

        $query_result_collections = new Collections\ArrayCollection($query_result); 
        $salesCycleArray = array();
        foreach ($query_result_collections as $key=>$val) {
            array_push($salesCycleArray,$val['salescyclename']);
        }
        
       
        $response = new Response(json_encode($salesCycleArray));
        $response->headers->set('Content-Type', 'application/json' . ';charset=UTF-8');
        // Allow all websites
        $response->headers->set('Access-Control-Allow-Origin', '*');

        // $response = new Response($this->get('serializer')->serialize($salesCycleArray, 'json'));
        //$data = $this->get('serializer')->serialize($posts, 'json');
        //$response->headers->set('Content-Type', 'application/json');

        
        // Or a predefined website
        //$response->headers->set('Access-Control-Allow-Origin', 'https://jsfiddle.net/');
        // You can set the allowed methods too, if you want    //$response->headers->set('Access-Control-Allow-Methods', 'POST, GET, PUT, DELETE, PATCH, OPTIONS');    
        return $response;
       
    }

    /**
     * @Route("/salescampaign", name="getSalesCampaign")
     */
    public function salesCampaignAction(Request $request)
    {
        $selectedSalesCycle = $request->query->get('selectedSalesCycle');
        $query_str = 'SELECT DISTINCT p.salescampaignname FROM AppBundle\Entity\rpt_sfa_pm p WHERE p.salescyclename=:selectedSalesCycle';

        $em = $this->getDoctrine()->getManager();
        $query = $em->createQuery($query_str)->setParameter('selectedSalesCycle',$selectedSalesCycle);  
        $query_result = $query->getResult(); 

        if (!$query_result) {
            throw $this->createNotFoundException(
                'No product found for id '.$productId
            );
            die();
        }

        $query_result_collections = new Collections\ArrayCollection($query_result); 
        $salesCampaignArray = array();
        foreach ($query_result_collections as $key=>$val) {
            array_push($salesCampaignArray,$val['salescampaignname']);
        }
       
        $response = new Response(json_encode($salesCampaignArray));
        $response->headers->set('Content-Type', 'application/json' . ';charset=UTF-8');
        // Allow all websites
        $response->headers->set('Access-Control-Allow-Origin', '*');
        return $response;
       
    }

    


}


       